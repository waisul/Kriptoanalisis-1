package frequensi;
import java.util.Scanner;
public class Frequency   
{  
     public static void main(String[] args) {  
         System.out.println("Masukkan kalimat:");  
        Scanner scan = new Scanner(System.in);
        String str = scan.nextLine();
        int[] freq = new int[str.length()];  
        int i, j;  
          
        //Convert string ke array
        char string[] = str.toCharArray();  
          
        for(i = 0; i <str.length(); i++) {  
            freq[i] = 1;  
            for(j = i+1; j <str.length(); j++) {  
                if(string[i] == string[j]) {  
                    freq[i]++;    
                    string[j] = '0';  
                }  
            }  
        }  
          
        //menampilkan karakter 
        System.out.println("frekuensi huruf yang muncul:");  
        for(i = 0; i <freq.length; i++) {  
            if(string[i] != ' ' && string[i] != '0')  
                System.out.println(string[i] + "-" + freq[i]);  
        }  
    }  
}  
