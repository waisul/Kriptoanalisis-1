/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas2matrikshuruf;
import java.util.Scanner;

/**
 *
 * Kelompok 2:
 * Gede Agus Surya Atmaja 1708561025
 * Kadek Dwi Oka Mahendra 1708561034
 */
public class no2_matrikshuruf {
    public static void main(String[] args){
        Scanner key=new Scanner(System.in);
        
        String kalimat;
        System.out.print("Masukkan Kalimat : ");
        kalimat=key.nextLine();
        
        char[] huruf = kalimat.toCharArray();
        int lenstr = huruf.length;
        
        int i,j,k;
        for (i=2; i<=lenstr; i++){ //baris
            int a, b=0, c=i;
            if (lenstr%i==0){
                a=lenstr/i;
            }
            else{
                a=lenstr/i+1;
            }
            
            for (j=0; j<a; j++) { //kolom
                b=b;
                
                for (k=1; k<i; k++) { //huruf
                   while(b<lenstr && b<=k){
                       System.out.print(huruf[b]);
                       b++;
                   }
                }
                System.out.print("\n");
                i=i+c;
            }
            i=c;
            System.out.print("\n");
        }
    }
}